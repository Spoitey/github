#!/usr/bin/env python3
"""Verify that an output IPA contains a SlowWave reference and embedded library."""
from __future__ import annotations
import plistlib, struct, sys, zipfile
from pathlib import Path

LOAD_PATH = b"@rpath/SlowWave.dylib"
LC_LOAD_DYLIB, LC_LOAD_WEAK_DYLIB = 0x0C, 0x80000018

def linked(binary: bytes) -> bool:
    if binary[:4] != b"\xcf\xfa\xed\xfe": return False
    _, _, _, _, ncmds, sizeofcmds, _, _ = struct.unpack_from("<IiiIIIII", binary, 0)
    pos = 32
    end = 32 + sizeofcmds
    for _ in range(ncmds):
        cmd, size = struct.unpack_from("<II", binary, pos)
        if cmd in (LC_LOAD_DYLIB, LC_LOAD_WEAK_DYLIB) and size >= 24:
            name_off = struct.unpack_from("<I", binary, pos + 8)[0]
            name = binary[pos+name_off:pos+size].split(b"\0",1)[0]
            if name == LOAD_PATH: return True
        pos += size
    return False

def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 verify_ipa.py path/to/SlowWaveYouTube.ipa", file=sys.stderr); return 2
    path = Path(sys.argv[1])
    with zipfile.ZipFile(path) as z:
        prefix = "Payload/YouTube.app/"
        app = plistlib.loads(z.read(prefix + "Info.plist"))
        binary = z.read(prefix + app["CFBundleExecutable"])
        dylib_path = prefix + "Frameworks/SlowWave.dylib"
        dylib = z.read(dylib_path)
        print("Bundle ID:", app.get("CFBundleIdentifier"))
        print("YouTube version:", app.get("CFBundleShortVersionString"))
        print("SlowWave linked:", linked(binary))
        print("SlowWave arm64 Mach-O:", dylib[:4] == b"\xcf\xfa\xed\xfe")
        print("Embedded dylib size:", len(dylib))
        return 0 if app.get("CFBundleIdentifier") == "com.google.ios.youtube" and linked(binary) and dylib[:4] == b"\xcf\xfa\xed\xfe" else 1
if __name__ == "__main__": raise SystemExit(main())

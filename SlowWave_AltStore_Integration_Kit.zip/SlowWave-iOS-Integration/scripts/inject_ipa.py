#!/usr/bin/env python3
"""Embed a Theos-built arm64 SlowWave.dylib into a YTKACE YouTube IPA.

The script only repackages and patches the Mach-O load commands. It does not
sign the app. Import the output into AltStore so it can resign it on-device.
"""
from __future__ import annotations
import argparse
import copy
import os
import plistlib
import stat
import struct
import sys
import zipfile
from pathlib import Path

LC_SEGMENT_64 = 0x19
LC_LOAD_DYLIB = 0x0C
LC_LOAD_WEAK_DYLIB = 0x80000018
LC_RPATH = 0x8000001C
CPU_TYPE_ARM64 = 0x0100000C
LOAD_PATH = b"@rpath/SlowWave.dylib"


def parse_macho(data: bytes):
    if len(data) < 32:
        raise ValueError("The app executable is too small to be a 64-bit Mach-O file.")
    magic, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags, reserved = struct.unpack_from("<IiiIIIII", data, 0)
    if magic != 0xFEEDFACF:
        raise ValueError("Expected a little-endian 64-bit Mach-O executable; this IPA uses a different format.")
    if cputype != CPU_TYPE_ARM64:
        raise ValueError(f"Expected arm64 YouTube executable; found cputype 0x{cputype & 0xffffffff:08x}.")
    command_end = 32 + sizeofcmds
    if command_end > len(data):
        raise ValueError("Malformed Mach-O: load commands extend past end of executable.")

    commands = []
    first_section_offset = None
    rpaths = []
    found_load = False
    offset = 32
    for _ in range(ncmds):
        if offset + 8 > command_end:
            raise ValueError("Malformed Mach-O load command.")
        cmd, cmdsize = struct.unpack_from("<II", data, offset)
        if cmdsize < 8 or offset + cmdsize > command_end:
            raise ValueError("Malformed Mach-O load command size.")
        commands.append((cmd, offset, cmdsize))
        if cmd in (LC_LOAD_DYLIB, LC_LOAD_WEAK_DYLIB):
            if cmdsize >= 24:
                name_off = struct.unpack_from("<I", data, offset + 8)[0]
                if 0 <= name_off < cmdsize:
                    name = data[offset + name_off:offset + cmdsize].split(b"\0", 1)[0]
                    if name == LOAD_PATH:
                        found_load = True
        elif cmd == LC_RPATH and cmdsize >= 12:
            path_off = struct.unpack_from("<I", data, offset + 8)[0]
            if 0 <= path_off < cmdsize:
                value = data[offset + path_off:offset + cmdsize].split(b"\0", 1)[0]
                rpaths.append(value)
        elif cmd == LC_SEGMENT_64 and cmdsize >= 72:
            nsects = struct.unpack_from("<I", data, offset + 64)[0]
            section_start = offset + 72
            if section_start + nsects * 80 > offset + cmdsize:
                raise ValueError("Malformed Mach-O segment section table.")
            for section_index in range(nsects):
                section_offset = section_start + section_index * 80
                _, _, file_offset = struct.unpack_from("<QQI", data, section_offset + 32)
                if file_offset > 0 and (first_section_offset is None or file_offset < first_section_offset):
                    first_section_offset = file_offset
        offset += cmdsize
    if offset != command_end:
        raise ValueError("Mach-O load-command byte count does not match header.")
    return {
        "ncmds": ncmds,
        "sizeofcmds": sizeofcmds,
        "command_end": command_end,
        "first_section_offset": first_section_offset,
        "rpaths": rpaths,
        "found_load": found_load,
    }


def make_weak_load_command(path: bytes) -> bytes:
    name = path + b"\0"
    cmdsize = (24 + len(name) + 7) & ~7
    command = struct.pack("<IIIIII", LC_LOAD_WEAK_DYLIB, cmdsize, 24, 0, 0, 0) + name
    return command + b"\0" * (cmdsize - len(command))


def patch_macho(data: bytes) -> tuple[bytes, str]:
    info = parse_macho(data)
    if info["found_load"]:
        return data, "The executable already references @rpath/SlowWave.dylib; load command unchanged."
    if b"@executable_path/Frameworks" not in info["rpaths"]:
        raise ValueError("The YouTube executable has no @executable_path/Frameworks rpath; refusing to patch blindly.")
    if info["first_section_offset"] is None:
        raise ValueError("Could not locate a Mach-O section to determine available header padding.")

    cmd = make_weak_load_command(LOAD_PATH)
    available = info["first_section_offset"] - info["command_end"]
    if len(cmd) > available:
        raise ValueError(
            f"Not enough zero-filled Mach-O header padding ({available} bytes available, {len(cmd)} required). "
            "No executable changes were made."
        )
    if any(data[info["command_end"]:info["command_end"] + len(cmd)]):
        raise ValueError("Mach-O header padding is not zero-filled; refusing to overwrite executable data.")

    out = bytearray(data)
    out[info["command_end"]:info["command_end"] + len(cmd)] = cmd
    struct.pack_into("<I", out, 16, info["ncmds"] + 1)
    struct.pack_into("<I", out, 20, info["sizeofcmds"] + len(cmd))
    # Reparse our own output so a malformed command never gets packaged.
    verify = parse_macho(bytes(out))
    if not verify["found_load"]:
        raise ValueError("Internal verification failed after adding load command.")
    return bytes(out), f"Added LC_LOAD_WEAK_DYLIB {LOAD_PATH.decode()} using {len(cmd)} bytes of header padding."


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ipa", type=Path, help="Original YouTube/YTKACE IPA")
    parser.add_argument("dylib", type=Path, help="Theos-built arm64 SlowWave.dylib")
    parser.add_argument("--out", type=Path, help="Output IPA (default: <input>_SlowWave.ipa)")
    args = parser.parse_args()

    ipa_path = args.ipa.expanduser().resolve()
    dylib_path = args.dylib.expanduser().resolve()
    out_path = (args.out.expanduser().resolve() if args.out else ipa_path.with_name(ipa_path.stem + "_SlowWave.ipa"))
    if not ipa_path.is_file():
        parser.error(f"IPA not found: {ipa_path}")
    if not dylib_path.is_file():
        parser.error(f"dylib not found: {dylib_path}")
    if ipa_path == out_path:
        parser.error("Output IPA must not overwrite the original input IPA.")

    dylib_data = dylib_path.read_bytes()
    if len(dylib_data) < 4 or dylib_data[:4] != b"\xcf\xfa\xed\xfe":
        parser.error("SlowWave.dylib is not a little-endian 64-bit Mach-O file. Build for iOS arm64 with Theos.")

    with zipfile.ZipFile(ipa_path, "r") as zin:
        names = set(zin.namelist())
        app_prefix = "Payload/YouTube.app/"
        info_name = app_prefix + "Info.plist"
        if info_name not in names:
            parser.error("The IPA does not contain Payload/YouTube.app/Info.plist.")
        app_info = plistlib.loads(zin.read(info_name))
        if app_info.get("CFBundleIdentifier") != "com.google.ios.youtube":
            parser.error(f"Unexpected app bundle identifier: {app_info.get('CFBundleIdentifier')!r}.")
        executable_name = app_info.get("CFBundleExecutable", "YouTube")
        executable_path = app_prefix + executable_name
        if executable_path not in names:
            parser.error(f"Main executable is missing from IPA: {executable_path}")
        if "Payload/YouTube.app/Frameworks/SlowWave.dylib" in names:
            print("Note: replacing an existing embedded SlowWave.dylib.")
        original_executable = zin.read(executable_path)
        patched_executable, patch_message = patch_macho(original_executable)

        out_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(out_path, "w", allowZip64=True, compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
                for entry in zin.infolist():
                    if entry.filename == executable_path:
                        data = patched_executable
                    elif entry.filename == "Payload/YouTube.app/Frameworks/SlowWave.dylib":
                        data = dylib_data
                    else:
                        data = zin.read(entry.filename)
                    zout.writestr(copy.copy(entry), data)
                if "Payload/YouTube.app/Frameworks/SlowWave.dylib" not in names:
                    entry = zipfile.ZipInfo("Payload/YouTube.app/Frameworks/SlowWave.dylib")
                    entry.compress_type = zipfile.ZIP_DEFLATED
                    entry.external_attr = (stat.S_IFREG | 0o755) << 16
                    entry.create_system = 3
                    zout.writestr(entry, dylib_data)
        except Exception:
            try:
                out_path.unlink(missing_ok=True)
            except OSError:
                pass
            raise

    with zipfile.ZipFile(out_path, "r") as check:
        bad = check.testzip()
        if bad is not None:
            out_path.unlink(missing_ok=True)
            raise RuntimeError(f"Output IPA failed ZIP integrity check at {bad}")
        output_bin = check.read(executable_path)
        if not parse_macho(output_bin)["found_load"]:
            out_path.unlink(missing_ok=True)
            raise RuntimeError("Output IPA verification failed: SlowWave load command is absent.")
        embedded = check.read("Payload/YouTube.app/Frameworks/SlowWave.dylib")
        if embedded != dylib_data:
            out_path.unlink(missing_ok=True)
            raise RuntimeError("Output IPA verification failed: embedded dylib does not match source dylib.")

    print(patch_message)
    print(f"Input:  {ipa_path} ({ipa_path.stat().st_size:,} bytes)")
    print(f"Output: {out_path} ({out_path.stat().st_size:,} bytes)")
    print("Important: the executable signature is now invalid. Import this IPA into AltStore so AltStore can resign it.")
    print("Not yet proof of runtime compatibility: test YouTube playback and confirm that the player uses AVPlayerItem audio tracks.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, zipfile.BadZipFile, OSError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2)

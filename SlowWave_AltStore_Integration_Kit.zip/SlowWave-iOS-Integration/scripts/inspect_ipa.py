#!/usr/bin/env python3
"""Inspect a YTKACE IPA and dry-run the SlowWave load-command patch."""
from __future__ import annotations
import plistlib
import sys
import zipfile
from pathlib import Path
from inject_ipa import parse_macho, patch_macho


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 inspect_ipa.py path/to/YTKACE.ipa", file=sys.stderr)
        return 2
    path = Path(sys.argv[1]).expanduser().resolve()
    if not path.is_file():
        print(f"IPA not found: {path}", file=sys.stderr)
        return 2
    with zipfile.ZipFile(path, "r") as archive:
        names = archive.namelist()
        prefix = "Payload/YouTube.app/"
        info_path = prefix + "Info.plist"
        if info_path not in names:
            print("Expected Payload/YouTube.app/Info.plist was not found.", file=sys.stderr)
            return 1
        info = plistlib.loads(archive.read(info_path))
        executable = prefix + info.get("CFBundleExecutable", "YouTube")
        binary = archive.read(executable)
        macho = parse_macho(binary)
        libraries = sorted(n for n in names if n.startswith(prefix + "Frameworks/") and n.endswith(".dylib"))
        print("IPA:", path)
        print("Bundle ID:", info.get("CFBundleIdentifier"))
        print("Version:", info.get("CFBundleShortVersionString"))
        print("Minimum iOS:", info.get("MinimumOSVersion"))
        print("Executable:", executable)
        print("Executable bytes:", f"{len(binary):,}")
        print("Mach-O load commands:", macho["ncmds"])
        print("Mach-O sizeofcmds:", macho["sizeofcmds"])
        print("Mach-O command end:", macho["command_end"])
        print("First section offset:", macho["first_section_offset"])
        print("Run paths:", ", ".join(p.decode("utf-8", "replace") for p in macho["rpaths"]))
        print("Bundled dylib count:", len(libraries))
        for library in libraries:
            print("  -", library.rsplit("/", 1)[-1])
        _, message = patch_macho(binary)
        print("Dry-run patch:", message)
        return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, zipfile.BadZipFile, OSError, KeyError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2)

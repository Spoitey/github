#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: $0 /path/to/YTKACE.ipa [output.ipa]" >&2
  exit 2
fi
IPA="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
OUT="${2:-$ROOT/dist/YTKACE_21.36.6_SlowWave.ipa}"

cd "$ROOT"
if [[ ! -x "$(command -v make || true)" ]]; then
  echo "Error: make was not found. Install Xcode and the Theos prerequisites first." >&2
  exit 2
fi
if [[ -z "${THEOS:-}" || ! -f "$THEOS/makefiles/common.mk" ]]; then
  echo "Error: THEOS is not set to a valid Theos installation." >&2
  echo "See https://theos.dev/docs/installation-macos" >&2
  exit 2
fi

make
DYLIB="$ROOT/dist/SlowWave.dylib"
if [[ ! -s "$DYLIB" ]]; then
  echo "Error: build did not produce $DYLIB" >&2
  exit 1
fi
python3 "$ROOT/scripts/inspect_ipa.py" "$IPA"
python3 "$ROOT/scripts/inject_ipa.py" "$IPA" "$DYLIB" --out "$OUT"
python3 "$ROOT/scripts/verify_ipa.py" "$OUT"
echo
echo "Created unsigned-for-AltStore IPA: $OUT"
echo "Import it into AltStore to resign it. Runtime compatibility is still unverified."

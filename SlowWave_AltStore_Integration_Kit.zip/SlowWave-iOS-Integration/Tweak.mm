#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaToolbox/MediaToolbox.h>
#import <CoreMedia/CoreMedia.h>
#import <AudioToolbox/AudioToolbox.h>
#import <objc/runtime.h>
#import <objc/message.h>

#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <cstdint>

// SlowWave native proof-of-concept for AVPlayerItem audio paths.
// It does not use the browser extension APIs. See README before installing.

static constexpr NSUInteger kSWMaxChannels = 2;
static constexpr float kSWPi = 3.14159265358979323846f;

static std::atomic<bool>  gSWEnabled{false};
static std::atomic<float> gSWSpeed{1.0f};
static std::atomic<float> gSWBass{8.0f};
static std::atomic<float> gSWReverb{82.0f};
static std::atomic<float> gSWDelay{150.0f};
static std::atomic<float> gSWMids{0.0f};
static std::atomic<float> gSWTreble{0.0f};
static std::atomic<float> gSWGain{-1.0f};
static std::atomic<float> gSWMix{100.0f};

static NSHashTable<AVPlayer *> *gSWPlayers;
static IMP gSWOriginalPlayerSetRate = NULL;
static IMP gSWOriginalReplaceItem = NULL;
static IMP gSWOriginalPlayerInitWithItem = NULL;
static IMP gSWOriginalOverlayLayout = NULL;
static BOOL gSWUIHookInstalled = NO;

static const void *kSWAudioMixMarker = &kSWAudioMixMarker;
static const void *kSWBaseRateMarker = &kSWBaseRateMarker;
static const void *kSWOverlayButtonMarker = &kSWOverlayButtonMarker;
static const void *kSWOverlayTargetMarker = &kSWOverlayTargetMarker;
static const void *kSWSliderLabelMarker = &kSWSliderLabelMarker;

static NSString * const kSWEnabledKey = @"SlowWave.Enabled";
static NSString * const kSWSpeedKey   = @"SlowWave.Speed";
static NSString * const kSWBassKey    = @"SlowWave.Bass";
static NSString * const kSWReverbKey  = @"SlowWave.Reverb";
static NSString * const kSWDelayKey   = @"SlowWave.Delay";
static NSString * const kSWMidsKey    = @"SlowWave.Mids";
static NSString * const kSWTrebleKey  = @"SlowWave.Treble";
static NSString * const kSWGainKey    = @"SlowWave.Gain";
static NSString * const kSWMixKey     = @"SlowWave.Mix";

static inline float SWClamp(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

static float SWReadFloat(NSUserDefaults *defaults, NSString *key, float fallback) {
    id value = [defaults objectForKey:key];
    return value == nil ? fallback : [value floatValue];
}

static void SWLoadSettings(void) {
    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    if ([d objectForKey:kSWEnabledKey] == nil) [d setBool:NO forKey:kSWEnabledKey];
    if ([d objectForKey:kSWSpeedKey] == nil) [d setFloat:1.0f forKey:kSWSpeedKey];
    if ([d objectForKey:kSWBassKey] == nil) [d setFloat:8.0f forKey:kSWBassKey];
    if ([d objectForKey:kSWReverbKey] == nil) [d setFloat:82.0f forKey:kSWReverbKey];
    if ([d objectForKey:kSWDelayKey] == nil) [d setFloat:150.0f forKey:kSWDelayKey];
    if ([d objectForKey:kSWMidsKey] == nil) [d setFloat:0.0f forKey:kSWMidsKey];
    if ([d objectForKey:kSWTrebleKey] == nil) [d setFloat:0.0f forKey:kSWTrebleKey];
    if ([d objectForKey:kSWGainKey] == nil) [d setFloat:-1.0f forKey:kSWGainKey];
    if ([d objectForKey:kSWMixKey] == nil) [d setFloat:100.0f forKey:kSWMixKey];

    gSWEnabled.store([d boolForKey:kSWEnabledKey]);
    gSWSpeed.store(SWClamp(SWReadFloat(d, kSWSpeedKey, 1.0f), 0.5f, 1.5f));
    gSWBass.store(SWClamp(SWReadFloat(d, kSWBassKey, 8.0f), 0.0f, 20.0f));
    gSWReverb.store(SWClamp(SWReadFloat(d, kSWReverbKey, 82.0f), 0.0f, 100.0f));
    gSWDelay.store(SWClamp(SWReadFloat(d, kSWDelayKey, 150.0f), 0.0f, 500.0f));
    gSWMids.store(SWClamp(SWReadFloat(d, kSWMidsKey, 0.0f), -12.0f, 12.0f));
    gSWTreble.store(SWClamp(SWReadFloat(d, kSWTrebleKey, 0.0f), -12.0f, 12.0f));
    gSWGain.store(SWClamp(SWReadFloat(d, kSWGainKey, -1.0f), -12.0f, 12.0f));
    gSWMix.store(SWClamp(SWReadFloat(d, kSWMixKey, 100.0f), 0.0f, 100.0f));
}

static void SWPersistSettings(void) {
    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    [d setBool:gSWEnabled.load() forKey:kSWEnabledKey];
    [d setFloat:gSWSpeed.load() forKey:kSWSpeedKey];
    [d setFloat:gSWBass.load() forKey:kSWBassKey];
    [d setFloat:gSWReverb.load() forKey:kSWReverbKey];
    [d setFloat:gSWDelay.load() forKey:kSWDelayKey];
    [d setFloat:gSWMids.load() forKey:kSWMidsKey];
    [d setFloat:gSWTreble.load() forKey:kSWTrebleKey];
    [d setFloat:gSWGain.load() forKey:kSWGainKey];
    [d setFloat:gSWMix.load() forKey:kSWMixKey];
}

#pragma mark - Realtime DSP used by MTAudioProcessingTap

struct SWTapState {
    double sampleRate;
    UInt32 channels;
    UInt32 bitsPerChannel;
    AudioFormatFlags formatFlags;
    bool isFloat;
    bool nonInterleaved;
    size_t capacity;
    size_t writeIndex;
    float *delay[kSWMaxChannels];
    float *combA[kSWMaxChannels];
    float *combB[kSWMaxChannels];
    float *combC[kSWMaxChannels];
    float *combD[kSWMaxChannels];
    float lowBass[kSWMaxChannels];
    float lowMid[kSWMaxChannels];
    float lowMidLow[kSWMaxChannels];
    float lowTreble[kSWMaxChannels];
};

static void SWFreeTapBuffers(SWTapState *s) {
    if (s == nullptr) return;
    for (NSUInteger ch = 0; ch < kSWMaxChannels; ++ch) {
        free(s->delay[ch]);  s->delay[ch] = nullptr;
        free(s->combA[ch]);  s->combA[ch] = nullptr;
        free(s->combB[ch]);  s->combB[ch] = nullptr;
        free(s->combC[ch]);  s->combC[ch] = nullptr;
        free(s->combD[ch]);  s->combD[ch] = nullptr;
    }
    s->capacity = 0;
    s->writeIndex = 0;
}

static void SWTapInit(MTAudioProcessingTapRef tap, void *clientInfo, void **tapStorageOut) {
    (void)tap;
    (void)clientInfo;
    SWTapState *s = static_cast<SWTapState *>(calloc(1, sizeof(SWTapState)));
    if (s != nullptr) {
        s->sampleRate = 44100.0;
        s->channels = 2;
        *tapStorageOut = s;
    } else {
        *tapStorageOut = nullptr;
    }
}

static void SWTapFinalize(MTAudioProcessingTapRef tap) {
    SWTapState *s = static_cast<SWTapState *>(MTAudioProcessingTapGetStorage(tap));
    if (s != nullptr) {
        SWFreeTapBuffers(s);
        free(s);
    }
}

static void SWTapPrepare(MTAudioProcessingTapRef tap, CMItemCount maxFrames,
                         const AudioStreamBasicDescription *processingFormat) {
    (void)maxFrames;
    SWTapState *s = static_cast<SWTapState *>(MTAudioProcessingTapGetStorage(tap));
    if (s == nullptr || processingFormat == nullptr) return;
    SWFreeTapBuffers(s);
    s->sampleRate = processingFormat->mSampleRate > 1000.0
        ? processingFormat->mSampleRate : 44100.0;
    s->channels = processingFormat->mChannelsPerFrame > 0
        ? processingFormat->mChannelsPerFrame : 2;
    s->bitsPerChannel = processingFormat->mBitsPerChannel;
    s->formatFlags = processingFormat->mFormatFlags;
    s->isFloat = (s->formatFlags & kAudioFormatFlagIsFloat) != 0;
    s->nonInterleaved = (s->formatFlags & kAudioFormatFlagIsNonInterleaved) != 0;
    s->capacity = static_cast<size_t>(s->sampleRate * 0.55) + 8;
    if (s->capacity < 1024) s->capacity = 1024;
    if (s->capacity > 300000) s->capacity = 300000;
    for (NSUInteger ch = 0; ch < kSWMaxChannels; ++ch) {
        s->delay[ch] = static_cast<float *>(calloc(s->capacity, sizeof(float)));
        s->combA[ch] = static_cast<float *>(calloc(s->capacity, sizeof(float)));
        s->combB[ch] = static_cast<float *>(calloc(s->capacity, sizeof(float)));
        s->combC[ch] = static_cast<float *>(calloc(s->capacity, sizeof(float)));
        s->combD[ch] = static_cast<float *>(calloc(s->capacity, sizeof(float)));
    }
    for (NSUInteger ch = 0; ch < kSWMaxChannels; ++ch) {
        if (s->delay[ch] == nullptr || s->combA[ch] == nullptr ||
            s->combB[ch] == nullptr || s->combC[ch] == nullptr ||
            s->combD[ch] == nullptr) {
            SWFreeTapBuffers(s);
            return; // Pass audio through if realtime buffers could not be allocated.
        }
    }
    s->writeIndex = 0;
}

static void SWTapUnprepare(MTAudioProcessingTapRef tap) {
    SWTapState *s = static_cast<SWTapState *>(MTAudioProcessingTapGetStorage(tap));
    SWFreeTapBuffers(s);
}

static inline size_t SWDelayIndex(const SWTapState *s, size_t delaySamples) {
    if (s->capacity == 0) return 0;
    delaySamples = delaySamples < s->capacity ? delaySamples : s->capacity - 1;
    return (s->writeIndex + s->capacity - delaySamples) % s->capacity;
}

static inline float SWDB(float db) { return powf(10.0f, db / 20.0f); }

static void SWProcessFrame(SWTapState *s, float samples[kSWMaxChannels], UInt32 liveChannels) {
    if (s == nullptr || s->capacity == 0) return;
    const bool enabled = gSWEnabled.load(std::memory_order_relaxed);
    const float bassDB = gSWBass.load(std::memory_order_relaxed);
    const float reverbAmount = gSWReverb.load(std::memory_order_relaxed) / 100.0f;
    const float delayMS = gSWDelay.load(std::memory_order_relaxed);
    const float midsDB = gSWMids.load(std::memory_order_relaxed);
    const float trebleDB = gSWTreble.load(std::memory_order_relaxed);
    const float gainDB = gSWGain.load(std::memory_order_relaxed);
    const float mix = gSWMix.load(std::memory_order_relaxed) / 100.0f;
    const float bassAlpha = 1.0f - expf(-2.0f * kSWPi * 135.0f / (float)s->sampleRate);
    const float midAlpha = 1.0f - expf(-2.0f * kSWPi * 1000.0f / (float)s->sampleRate);
    const float midLowAlpha = 1.0f - expf(-2.0f * kSWPi * 300.0f / (float)s->sampleRate);
    const float trebleAlpha = 1.0f - expf(-2.0f * kSWPi * 5000.0f / (float)s->sampleRate);
    const float bassDelta = SWDB(bassDB) - 1.0f;
    const float midsDelta = SWDB(midsDB) - 1.0f;
    const float trebleDelta = SWDB(trebleDB) - 1.0f;
    const float gain = SWDB(gainDB);
    const float bassComp = 1.0f / sqrtf(1.0f + bassDB / 8.5f);
    const size_t delaySamples = (size_t)SWClamp(delayMS * (float)s->sampleRate / 1000.0f, 1.0f, (float)(s->capacity - 1));
    const size_t combA = (size_t)(s->sampleRate * 0.0297);
    const size_t combB = (size_t)(s->sampleRate * 0.0371);
    const size_t combC = (size_t)(s->sampleRate * 0.0411);
    const size_t combD = (size_t)(s->sampleRate * 0.0537);
    const float delayWet = SWClamp(delayMS / 500.0f, 0.0f, 1.0f) * 0.36f;
    const float reverbWet = reverbAmount * 0.68f;
    const float dryGain = 1.0f - SWClamp(mix * (delayWet + reverbWet) * 0.42f, 0.0f, 0.78f);

    for (UInt32 ch = 0; ch < liveChannels && ch < kSWMaxChannels; ++ch) {
        const float x = samples[ch];
        if (!enabled) {
            s->delay[ch][s->writeIndex] = 0.0f;
            s->combA[ch][s->writeIndex] = 0.0f;
            s->combB[ch][s->writeIndex] = 0.0f;
            s->combC[ch][s->writeIndex] = 0.0f;
            s->combD[ch][s->writeIndex] = 0.0f;
            s->lowBass[ch] = s->lowMid[ch] = s->lowMidLow[ch] = s->lowTreble[ch] = 0.0f;
            continue;
        }

        float y = x;
        s->lowBass[ch] += bassAlpha * (x - s->lowBass[ch]);
        y += s->lowBass[ch] * bassDelta;
        s->lowMid[ch] += midAlpha * (x - s->lowMid[ch]);
        s->lowMidLow[ch] += midLowAlpha * (x - s->lowMidLow[ch]);
        y += (s->lowMid[ch] - s->lowMidLow[ch]) * midsDelta;
        s->lowTreble[ch] += trebleAlpha * (x - s->lowTreble[ch]);
        y += (x - s->lowTreble[ch]) * trebleDelta;

        const float delayed = s->delay[ch][SWDelayIndex(s, delaySamples)];
        s->delay[ch][s->writeIndex] = y + delayed * 0.24f;
        const float a = s->combA[ch][SWDelayIndex(s, combA)];
        const float b = s->combB[ch][SWDelayIndex(s, combB)];
        const float c = s->combC[ch][SWDelayIndex(s, combC)];
        const float d = s->combD[ch][SWDelayIndex(s, combD)];
        s->combA[ch][s->writeIndex] = y * 0.23f + a * 0.71f;
        s->combB[ch][s->writeIndex] = y * 0.21f + b * 0.72f;
        s->combC[ch][s->writeIndex] = y * 0.19f + c * 0.73f;
        s->combD[ch][s->writeIndex] = y * 0.17f + d * 0.74f;
        const float reverbSignal = (a + b + c + d) * 0.25f;
        float wetSignal = delayed * delayWet + reverbSignal * reverbWet;
        float output = (y * dryGain + wetSignal * mix) * gain * bassComp;
        // Soft protection against runaway peaks when bass and wet mix are both high.
        if (output > 1.25f) output = 1.25f + (output - 1.25f) * 0.08f;
        if (output < -1.25f) output = -1.25f + (output + 1.25f) * 0.08f;
        samples[ch] = output;
    }
    s->writeIndex = (s->writeIndex + 1) % s->capacity;
}

static void SWTapProcess(MTAudioProcessingTapRef tap, CMItemCount numberFrames,
                         MTAudioProcessingTapFlags flags,
                         AudioBufferList *bufferListInOut,
                         CMItemCount *numberFramesOut,
                         MTAudioProcessingTapFlags *flagsOut) {
    OSStatus status = MTAudioProcessingTapGetSourceAudio(tap, numberFrames,
        bufferListInOut, flagsOut, nullptr, numberFramesOut);
    if (status != noErr || bufferListInOut == nullptr) return;
    SWTapState *s = static_cast<SWTapState *>(MTAudioProcessingTapGetStorage(tap));
    if (s == nullptr || s->capacity == 0) return;
    (void)flags;

    const CMItemCount frames = numberFramesOut != nullptr ? *numberFramesOut : numberFrames;
    const UInt32 declaredChannels = s->channels > 0 ? s->channels : 2;
    const UInt32 liveChannels = (UInt32)MIN((NSUInteger)declaredChannels, kSWMaxChannels);
    const bool isFloat32 = s->isFloat && s->bitsPerChannel == 32;
    const bool isInt16 = !s->isFloat && s->bitsPerChannel == 16;
    if (!isFloat32 && !isInt16) return; // safely pass through formats we don't understand

    if (s->nonInterleaved && bufferListInOut->mNumberBuffers >= 1) {
        for (CMItemCount frame = 0; frame < frames; ++frame) {
            float samples[kSWMaxChannels] = {0.0f, 0.0f};
            UInt32 count = (UInt32)MIN((NSUInteger)bufferListInOut->mNumberBuffers, (NSUInteger)liveChannels);
            for (UInt32 ch = 0; ch < count; ++ch) {
                AudioBuffer *buffer = &bufferListInOut->mBuffers[ch];
                if (buffer->mData == nullptr) continue;
                if (isFloat32) samples[ch] = static_cast<float *>(buffer->mData)[frame];
                else samples[ch] = (float)static_cast<int16_t *>(buffer->mData)[frame] / 32768.0f;
            }
            SWProcessFrame(s, samples, count);
            for (UInt32 ch = 0; ch < count; ++ch) {
                AudioBuffer *buffer = &bufferListInOut->mBuffers[ch];
                if (buffer->mData == nullptr) continue;
                if (isFloat32) static_cast<float *>(buffer->mData)[frame] = samples[ch];
                else {
                    float v = SWClamp(samples[ch], -1.0f, 0.999969f);
                    static_cast<int16_t *>(buffer->mData)[frame] = (int16_t)lrintf(v * 32768.0f);
                }
            }
        }
    } else if (bufferListInOut->mNumberBuffers > 0) {
        AudioBuffer *buffer = &bufferListInOut->mBuffers[0];
        if (buffer->mData == nullptr) return;
        const UInt32 channels = declaredChannels > 0 ? declaredChannels : 1;
        for (CMItemCount frame = 0; frame < frames; ++frame) {
            float samples[kSWMaxChannels] = {0.0f, 0.0f};
            for (UInt32 ch = 0; ch < liveChannels; ++ch) {
                const size_t index = (size_t)frame * channels + ch;
                if (isFloat32) samples[ch] = static_cast<float *>(buffer->mData)[index];
                else samples[ch] = (float)static_cast<int16_t *>(buffer->mData)[index] / 32768.0f;
            }
            SWProcessFrame(s, samples, liveChannels);
            for (UInt32 ch = 0; ch < liveChannels; ++ch) {
                const size_t index = (size_t)frame * channels + ch;
                if (isFloat32) static_cast<float *>(buffer->mData)[index] = samples[ch];
                else {
                    float v = SWClamp(samples[ch], -1.0f, 0.999969f);
                    static_cast<int16_t *>(buffer->mData)[index] = (int16_t)lrintf(v * 32768.0f);
                }
            }
        }
    }
}

static MTAudioProcessingTapRef SWCreateAudioTap(void) {
    MTAudioProcessingTapCallbacks callbacks = {};
    callbacks.version = kMTAudioProcessingTapCallbacksVersion_0;
    callbacks.init = SWTapInit;
    callbacks.finalize = SWTapFinalize;
    callbacks.prepare = SWTapPrepare;
    callbacks.unprepare = SWTapUnprepare;
    callbacks.process = SWTapProcess;
    MTAudioProcessingTapRef tap = nullptr;
    OSStatus status = MTAudioProcessingTapCreate(kCFAllocatorDefault, &callbacks,
        kMTAudioProcessingTapCreationFlag_PreEffects, &tap);
    return status == noErr ? tap : nullptr;
}

#pragma mark - AVPlayerItem audio-mix attachment

static void SWAttachAudioTap(AVPlayerItem *item) {
    if (item == nil || !gSWEnabled.load() || ![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.google.ios.youtube"]) return;
    @synchronized (item) {
        if (objc_getAssociatedObject(item, kSWAudioMixMarker) != nil) return;
        objc_setAssociatedObject(item, kSWAudioMixMarker, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }

    AVAsset *asset = item.asset;
    if (asset == nil) {
        objc_setAssociatedObject(item, kSWAudioMixMarker, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        return;
    }
    [asset loadValuesAsynchronouslyForKeys:@[@"tracks"] completionHandler:^{
        NSError *loadError = nil;
        if ([asset statusOfValueForKey:@"tracks" error:&loadError] != AVKeyValueStatusLoaded) {
            objc_setAssociatedObject(item, kSWAudioMixMarker, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            return;
        }
        NSArray<AVAssetTrack *> *tracks = [asset tracksWithMediaType:AVMediaTypeAudio];
        if (tracks.count == 0) {
            objc_setAssociatedObject(item, kSWAudioMixMarker, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (item.status == AVPlayerItemStatusFailed) {
                objc_setAssociatedObject(item, kSWAudioMixMarker, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                return;
            }
            AVAudioMix *oldMix = item.audioMix;
            NSArray<AVAudioMixInputParameters *> *oldParameters = oldMix.inputParameters ?: @[];
            NSMutableArray<AVAudioMixInputParameters *> *newParameters = [NSMutableArray array];
            NSMutableSet<NSNumber *> *seenIDs = [NSMutableSet set];
            for (AVAssetTrack *track in tracks) {
                NSNumber *trackKey = @(track.trackID);
                [seenIDs addObject:trackKey];
                AVAudioMixInputParameters *prior = nil;
                for (AVAudioMixInputParameters *candidate in oldParameters) {
                    if (candidate.trackID == track.trackID) { prior = candidate; break; }
                }
                if (prior != nil && [prior isKindOfClass:AVMutableAudioMixInputParameters.class] &&
                    ((AVMutableAudioMixInputParameters *)prior).audioTapProcessor != nullptr) {
                    [newParameters addObject:prior];
                    continue;
                }
                AVMutableAudioMixInputParameters *input = prior != nil
                    ? [prior mutableCopy]
                    : [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:track];
                MTAudioProcessingTapRef tap = SWCreateAudioTap();
                if (tap == nullptr) {
                    [newParameters addObject:input];
                    continue;
                }
                input.audioTapProcessor = tap;
                CFRelease(tap); // audioTapProcessor retains the Core Foundation object
                [newParameters addObject:input];
            }
            for (AVAudioMixInputParameters *prior in oldParameters) {
                if (![seenIDs containsObject:@(prior.trackID)]) [newParameters addObject:prior];
            }
            if (newParameters.count == 0) {
                objc_setAssociatedObject(item, kSWAudioMixMarker, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                return;
            }
            AVMutableAudioMix *mix = [AVMutableAudioMix audioMix];
            mix.inputParameters = newParameters;
            item.audioMix = mix;
            objc_setAssociatedObject(item, kSWAudioMixMarker, mix, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        });
    }];
}

static id SWPlayerInitWithItem(id self, SEL selector, AVPlayerItem *item) {
    using InitFn = id (*)(id, SEL, AVPlayerItem *);
    id result = reinterpret_cast<InitFn>(gSWOriginalPlayerInitWithItem)(self, selector, item);
    if (result != nil && item != nil) {
        @synchronized (gSWPlayers) { [gSWPlayers addObject:(AVPlayer *)result]; }
        SWAttachAudioTap(item);
    }
    return result;
}

static void SWPlayerReplaceItem(id self, SEL selector, AVPlayerItem *item) {
    using ReplaceFn = void (*)(id, SEL, AVPlayerItem *);
    @synchronized (gSWPlayers) { [gSWPlayers addObject:(AVPlayer *)self]; }
    if (item != nil) SWAttachAudioTap(item);
    reinterpret_cast<ReplaceFn>(gSWOriginalReplaceItem)(self, selector, item);
}

static void SWApplySpeedToPlayers(void) {
    if (gSWOriginalPlayerSetRate == NULL || gSWPlayers == nil) return;
    NSArray<AVPlayer *> *players = nil;
    @synchronized (gSWPlayers) { players = gSWPlayers.allObjects; }
    const BOOL enabled = gSWEnabled.load();
    const float selected = gSWSpeed.load();
    for (AVPlayer *player in players) {
        if (player.rate <= 0.0f) continue;
        NSNumber *base = objc_getAssociatedObject(player, kSWBaseRateMarker);
        float normalRate = base != nil ? base.floatValue : 1.0f;
        float effective = enabled ? selected : normalRate;
        if (enabled && player.currentItem != nil) {
            player.currentItem.audioTimePitchAlgorithm = AVAudioTimePitchAlgorithmVarispeed;
        }
        using RateFn = void (*)(id, SEL, float);
        reinterpret_cast<RateFn>(gSWOriginalPlayerSetRate)(player, @selector(setRate:), effective);
    }
}

static void SWPlayerSetRate(id self, SEL selector, float rate) {
    using RateFn = void (*)(id, SEL, float);
    @synchronized (gSWPlayers) { [gSWPlayers addObject:(AVPlayer *)self]; }
    if (rate > 0.0f) objc_setAssociatedObject(self, kSWBaseRateMarker, @(rate), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    float effective = rate;
    if (rate > 0.0f && gSWEnabled.load()) {
        effective = gSWSpeed.load();
        AVPlayerItem *item = ((AVPlayer *)self).currentItem;
        if (item != nil) item.audioTimePitchAlgorithm = AVAudioTimePitchAlgorithmVarispeed;
    }
    reinterpret_cast<RateFn>(gSWOriginalPlayerSetRate)(self, selector, effective);
}

static void SWInstallMethodHook(Class cls, SEL selector, IMP replacement, IMP *originalOut) {
    if (cls == Nil || selector == nullptr || replacement == nullptr || originalOut == nullptr) return;
    Method method = class_getInstanceMethod(cls, selector);
    if (method == nullptr) return;
    *originalOut = method_setImplementation(method, replacement);
}

#pragma mark - Settings panel

@interface SWSettingsViewController : UIViewController
@property(nonatomic, strong) UIStackView *stack;
@property(nonatomic, strong) UISwitch *enabledSwitch;
@property(nonatomic, strong) UISegmentedControl *presets;
- (void)settingChanged:(UISwitch *)sender;
- (void)sliderChanged:(UISlider *)sender;
- (void)addSliderWithTitle:(NSString *)title tag:(NSInteger)tag min:(float)minimum max:(float)maximum value:(float)value;
- (void)presetChanged:(UISegmentedControl *)sender;
- (void)donePressed;
- (void)refreshControls;
@end

static NSString *SWSliderValueText(NSInteger tag, float value) {
    switch (tag) {
        case 1: return [NSString stringWithFormat:@"%.2fx", value];
        case 2: return [NSString stringWithFormat:@"%.0f dB", value];
        case 3: return [NSString stringWithFormat:@"%.0f%%", value];
        case 4: return [NSString stringWithFormat:@"%.0f ms", value];
        case 5: case 6: case 7: return [NSString stringWithFormat:@"%+.0f dB", value];
        case 8: return [NSString stringWithFormat:@"%.0f%%", value];
        default: return [NSString stringWithFormat:@"%.0f", value];
    }
}

@implementation SWSettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"SlowWave";
    self.view.backgroundColor = UIColor.systemBackgroundColor;

    UIScrollView *scroll = [UIScrollView new];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scroll];
    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8.0],
        [scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:18.0],
        [scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-18.0],
        [scroll.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-8.0]
    ]];

    self.stack = [[UIStackView alloc] initWithFrame:CGRectZero];
    self.stack.axis = UILayoutConstraintAxisVertical;
    self.stack.spacing = 16.0;
    self.stack.alignment = UIStackViewAlignmentFill;
    self.stack.translatesAutoresizingMaskIntoConstraints = NO;
    [scroll addSubview:self.stack];
    [NSLayoutConstraint activateConstraints:@[
        [self.stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:12.0],
        [self.stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor],
        [self.stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor],
        [self.stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-12.0],
        [self.stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor]
    ]];

    UILabel *heading = [UILabel new];
    heading.text = @"SlowWave Audio Effects";
    heading.font = [UIFont systemFontOfSize:23.0 weight:UIFontWeightBold];
    [self.stack addArrangedSubview:heading];

    UIStackView *enabledRow = [[UIStackView alloc] initWithFrame:CGRectZero];
    enabledRow.axis = UILayoutConstraintAxisHorizontal;
    enabledRow.alignment = UIStackViewAlignmentCenter;
    enabledRow.distribution = UIStackViewDistributionEqualSpacing;
    UILabel *enabledLabel = [UILabel new];
    enabledLabel.text = @"Enable SlowWave";
    enabledLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightSemibold];
    self.enabledSwitch = [UISwitch new];
    self.enabledSwitch.on = gSWEnabled.load();
    [self.enabledSwitch addTarget:self action:@selector(settingChanged:) forControlEvents:UIControlEventValueChanged];
    [enabledRow addArrangedSubview:enabledLabel];
    [enabledRow addArrangedSubview:self.enabledSwitch];
    [self.stack addArrangedSubview:enabledRow];

    UILabel *presetLabel = [UILabel new];
    presetLabel.text = @"Presets";
    presetLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightSemibold];
    [self.stack addArrangedSubview:presetLabel];
    self.presets = [[UISegmentedControl alloc] initWithItems:@[@"Slow", @"Ultra", @"Dreamy", @"Bass", @"Clean"]];
    self.presets.selectedSegmentIndex = UISegmentedControlNoSegment;
    [self.presets addTarget:self action:@selector(presetChanged:) forControlEvents:UIControlEventValueChanged];
    [self.stack addArrangedSubview:self.presets];

    [self addSliderWithTitle:@"Speed" tag:1 min:0.5 max:1.5 value:gSWSpeed.load()];
    [self addSliderWithTitle:@"Bass boost" tag:2 min:0 max:20 value:gSWBass.load()];
    [self addSliderWithTitle:@"Reverb" tag:3 min:0 max:100 value:gSWReverb.load()];
    [self addSliderWithTitle:@"Delay" tag:4 min:0 max:500 value:gSWDelay.load()];
    [self addSliderWithTitle:@"Mids" tag:5 min:-12 max:12 value:gSWMids.load()];
    [self addSliderWithTitle:@"Treble" tag:6 min:-12 max:12 value:gSWTreble.load()];
    [self addSliderWithTitle:@"Master gain" tag:7 min:-12 max:12 value:gSWGain.load()];
    [self addSliderWithTitle:@"Wet mix" tag:8 min:0 max:100 value:gSWMix.load()];

    UIButton *done = [UIButton buttonWithType:UIButtonTypeSystem];
    [done setTitle:@"Done" forState:UIControlStateNormal];
    done.titleLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightSemibold];
    done.backgroundColor = [UIColor secondarySystemBackgroundColor];
    done.layer.cornerRadius = 12.0;
    done.contentEdgeInsets = UIEdgeInsetsMake(12.0, 20.0, 12.0, 20.0);
    [done addTarget:self action:@selector(donePressed) forControlEvents:UIControlEventTouchUpInside];
    [self.stack addArrangedSubview:done];
}

- (void)addSliderWithTitle:(NSString *)title tag:(NSInteger)tag min:(float)minimum max:(float)maximum value:(float)value {
    UIStackView *row = [[UIStackView alloc] initWithFrame:CGRectZero];
    row.axis = UILayoutConstraintAxisVertical;
    row.spacing = 6.0;
    UILabel *titleLabel = [UILabel new];
    titleLabel.text = title;
    titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightMedium];
    UILabel *valueLabel = [UILabel new];
    valueLabel.textAlignment = NSTextAlignmentRight;
    valueLabel.font = [UIFont monospacedDigitSystemFontOfSize:13.0 weight:UIFontWeightRegular];
    valueLabel.textColor = UIColor.secondaryLabelColor;
    valueLabel.text = SWSliderValueText(tag, value);
    UISlider *slider = [UISlider new];
    slider.minimumValue = minimum;
    slider.maximumValue = maximum;
    slider.value = value;
    slider.tag = tag;
    slider.continuous = YES;
    slider.minimumTrackTintColor = UIColor.systemBlueColor;
    [slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
    objc_setAssociatedObject(slider, kSWSliderLabelMarker, valueLabel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    UIStackView *top = [[UIStackView alloc] initWithArrangedSubviews:@[titleLabel, valueLabel]];
    top.axis = UILayoutConstraintAxisHorizontal;
    top.distribution = UIStackViewDistributionEqualSpacing;
    [row addArrangedSubview:top];
    [row addArrangedSubview:slider];
    [self.stack addArrangedSubview:row];
}

- (void)settingChanged:(UISwitch *)sender {
    gSWEnabled.store(sender.isOn);
    SWPersistSettings();
    SWApplySpeedToPlayers();
    if (sender.isOn) {
        NSArray<AVPlayer *> *players = nil;
        @synchronized (gSWPlayers) { players = gSWPlayers.allObjects; }
        for (AVPlayer *player in players) SWAttachAudioTap(player.currentItem);
    }
}

- (void)sliderChanged:(UISlider *)sender {
    float value = sender.value;
    UILabel *label = objc_getAssociatedObject(sender, kSWSliderLabelMarker);
    if (label != nil) label.text = SWSliderValueText(sender.tag, value);
    switch (sender.tag) {
        case 1: gSWSpeed.store(SWClamp(value, 0.5f, 1.5f)); break;
        case 2: gSWBass.store(SWClamp(value, 0.0f, 20.0f)); break;
        case 3: gSWReverb.store(SWClamp(value, 0.0f, 100.0f)); break;
        case 4: gSWDelay.store(SWClamp(value, 0.0f, 500.0f)); break;
        case 5: gSWMids.store(SWClamp(value, -12.0f, 12.0f)); break;
        case 6: gSWTreble.store(SWClamp(value, -12.0f, 12.0f)); break;
        case 7: gSWGain.store(SWClamp(value, -12.0f, 12.0f)); break;
        case 8: gSWMix.store(SWClamp(value, 0.0f, 100.0f)); break;
        default: break;
    }
    SWPersistSettings();
    if (sender.tag == 1) SWApplySpeedToPlayers();
}

- (void)presetChanged:(UISegmentedControl *)sender {
    NSDictionary<NSString *, NSNumber *> *preset = nil;
    switch (sender.selectedSegmentIndex) {
        case 0: preset = @{@"speed":@0.75, @"bass":@8, @"reverb":@82, @"delay":@150, @"mids":@0, @"treble":@0, @"gain":@(-1), @"mix":@100}; break;
        case 1: preset = @{@"speed":@1.0, @"bass":@7, @"reverb":@92, @"delay":@200, @"mids":@1, @"treble":@(-2), @"gain":@(-2), @"mix":@100}; break;
        case 2: preset = @{@"speed":@0.72, @"bass":@6, @"reverb":@88, @"delay":@230, @"mids":@1, @"treble":@2, @"gain":@(-2), @"mix":@100}; break;
        case 3: preset = @{@"speed":@1.0, @"bass":@18, @"reverb":@8, @"delay":@40, @"mids":@1, @"treble":@1, @"gain":@(-5), @"mix":@85}; break;
        case 4: preset = @{@"speed":@1.0, @"bass":@0, @"reverb":@0, @"delay":@0, @"mids":@0, @"treble":@0, @"gain":@0, @"mix":@0}; break;
        default: return;
    }
    gSWEnabled.store(YES);
    gSWSpeed.store(preset[@"speed"].floatValue);
    gSWBass.store(preset[@"bass"].floatValue);
    gSWReverb.store(preset[@"reverb"].floatValue);
    gSWDelay.store(preset[@"delay"].floatValue);
    gSWMids.store(preset[@"mids"].floatValue);
    gSWTreble.store(preset[@"treble"].floatValue);
    gSWGain.store(preset[@"gain"].floatValue);
    gSWMix.store(preset[@"mix"].floatValue);
    self.enabledSwitch.on = YES;
    SWPersistSettings();
    [self refreshControls];
    SWApplySpeedToPlayers();
    NSArray<AVPlayer *> *players = nil;
    @synchronized (gSWPlayers) { players = gSWPlayers.allObjects; }
    for (AVPlayer *player in players) SWAttachAudioTap(player.currentItem);
}

- (void)refreshControls {
    self.enabledSwitch.on = gSWEnabled.load();
    __block void (^visit)(UIView *);
    visit = ^(UIView *view) {
        if ([view isKindOfClass:UISlider.class]) {
            UISlider *slider = (UISlider *)view;
            switch (slider.tag) {
                case 1: slider.value = gSWSpeed.load(); break;
                case 2: slider.value = gSWBass.load(); break;
                case 3: slider.value = gSWReverb.load(); break;
                case 4: slider.value = gSWDelay.load(); break;
                case 5: slider.value = gSWMids.load(); break;
                case 6: slider.value = gSWTreble.load(); break;
                case 7: slider.value = gSWGain.load(); break;
                case 8: slider.value = gSWMix.load(); break;
                default: break;
            }
            UILabel *valueLabel = objc_getAssociatedObject(slider, kSWSliderLabelMarker);
            if (valueLabel != nil) valueLabel.text = SWSliderValueText(slider.tag, slider.value);
        }
        for (UIView *child in view.subviews) visit(child);
    };
    visit(self.view);
}

- (void)donePressed { [self dismissViewControllerAnimated:YES completion:nil]; }
@end

#pragma mark - Overlay button

@interface SWOverlayTarget : NSObject
- (void)openSlowWave:(UIButton *)sender;
@end

static UIViewController *SWTopViewController(void) {
    UIWindow *window = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
            if (candidate.isKeyWindow) { window = candidate; break; }
        }
        if (window != nil) break;
    }
    UIViewController *top = window.rootViewController;
    while (top != nil) {
        UIViewController *next = top.presentedViewController;
        if ([top isKindOfClass:UINavigationController.class]) next = ((UINavigationController *)top).visibleViewController ?: next;
        else if ([top isKindOfClass:UITabBarController.class]) next = ((UITabBarController *)top).selectedViewController ?: next;
        if (next == nil || next == top) break;
        top = next;
    }
    return top;
}

@implementation SWOverlayTarget
- (void)openSlowWave:(UIButton *)sender {
    (void)sender;
    UIViewController *top = SWTopViewController();
    if (top == nil || [top isKindOfClass:SWSettingsViewController.class]) return;
    SWSettingsViewController *settings = [SWSettingsViewController new];
    settings.modalPresentationStyle = UIModalPresentationPageSheet;
    if (@available(iOS 15.0, *)) {
        settings.sheetPresentationController.detents = @[UISheetPresentationControllerDetent.mediumDetent, UISheetPresentationControllerDetent.largeDetent];
        settings.sheetPresentationController.prefersGrabberVisible = YES;
    }
    [top presentViewController:settings animated:YES completion:nil];
}
@end

static void SWEnsureOverlayButton(UIView *view) {
    if (![view isKindOfClass:UIView.class] || view.window == nil) return;
    if (objc_getAssociatedObject(view, kSWOverlayButtonMarker) != nil) return;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"SW" forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBold];
    button.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.82];
    button.layer.cornerRadius = 16.0;
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.18].CGColor;
    button.translatesAutoresizingMaskIntoConstraints = NO;
    SWOverlayTarget *target = [SWOverlayTarget new];
    [button addTarget:target action:@selector(openSlowWave:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    [NSLayoutConstraint activateConstraints:@[
        [button.trailingAnchor constraintEqualToAnchor:view.trailingAnchor constant:-14.0],
        [button.topAnchor constraintEqualToAnchor:view.safeAreaLayoutGuide.topAnchor constant:14.0],
        [button.widthAnchor constraintEqualToConstant:44.0],
        [button.heightAnchor constraintEqualToConstant:32.0]
    ]];
    objc_setAssociatedObject(view, kSWOverlayButtonMarker, button, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(view, kSWOverlayTargetMarker, target, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

static void SWOverlayLayout(id self, SEL selector) {
    using LayoutFn = void (*)(id, SEL);
    if (gSWOriginalOverlayLayout != NULL) reinterpret_cast<LayoutFn>(gSWOriginalOverlayLayout)(self, selector);
    if ([self isKindOfClass:UIView.class]) SWEnsureOverlayButton((UIView *)self);
    else if ([self isKindOfClass:UIViewController.class]) SWEnsureOverlayButton(((UIViewController *)self).view);
}

static BOOL SWHookLayoutForClass(Class cls, SEL selector) {
    if (cls == Nil) return NO;
    Method m = class_getInstanceMethod(cls, selector);
    if (m == nullptr) return NO;
    IMP original = method_getImplementation(m);
    const char *types = method_getTypeEncoding(m);
    if (class_addMethod(cls, selector, (IMP)SWOverlayLayout, types)) {
        gSWOriginalOverlayLayout = original;
    } else {
        gSWOriginalOverlayLayout = method_setImplementation(m, (IMP)SWOverlayLayout);
    }
    return YES;
}

static void SWTryInstallUIHook(NSUInteger attemptsRemaining) {
    if (gSWUIHookInstalled) return;
    Class overlay = NSClassFromString(@"YTMainAppVideoPlayerOverlayView");
    if (overlay != Nil && SWHookLayoutForClass(overlay, @selector(layoutSubviews))) {
        gSWUIHookInstalled = YES;
        return;
    }
    Class playerController = NSClassFromString(@"YTPlayerViewController");
    if (playerController != Nil && SWHookLayoutForClass(playerController, @selector(viewDidLayoutSubviews))) {
        gSWUIHookInstalled = YES;
        return;
    }
    if (attemptsRemaining > 0) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(500 * NSEC_PER_MSEC)), dispatch_get_main_queue(), ^{
            SWTryInstallUIHook(attemptsRemaining - 1);
        });
    }
}

__attribute__((constructor)) static void SWInitialize(void) {
    @autoreleasepool {
        if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.google.ios.youtube"]) return;
        SWLoadSettings();
        gSWPlayers = [NSHashTable weakObjectsHashTable];
        Class playerClass = NSClassFromString(@"AVPlayer");
        SWInstallMethodHook(playerClass, @selector(setRate:), (IMP)SWPlayerSetRate, &gSWOriginalPlayerSetRate);
        SWInstallMethodHook(playerClass, @selector(replaceCurrentItemWithPlayerItem:), (IMP)SWPlayerReplaceItem, &gSWOriginalReplaceItem);
        SWInstallMethodHook(playerClass, @selector(initWithPlayerItem:), (IMP)SWPlayerInitWithItem, &gSWOriginalPlayerInitWithItem);
        dispatch_async(dispatch_get_main_queue(), ^{ SWTryInstallUIHook(20); });
    }
}

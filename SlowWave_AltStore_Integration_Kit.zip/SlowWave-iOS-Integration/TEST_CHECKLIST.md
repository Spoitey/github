# Device test checklist (after you build and AltStore-sign it)

Test on a spare/test install first and keep the original IPA available for rollback.

- [ ] AltStore installs the output IPA without a signature or provisioning error.
- [ ] YouTube launches and can play a normal video.
- [ ] The `SW` button appears in the player overlay.
- [ ] The settings sheet opens and the switch remains on/off after reopening it.
- [ ] 0.75× speed is audibly slower and changes pitch; toggling SlowWave off restores normal speed.
- [ ] Reverb/delay are audibly present on a video with sustained audio, and bass/EQ/gain sliders make audible changes.
- [ ] Moving to another video, Shorts, live content, and audio-only/background playback does not crash or break playback.
- [ ] Force-quitting and reopening YouTube does not cause a crash loop.

## If any item fails

1. Stop testing and remove the modified app.
2. Reinstall the original IPA from your saved copy.
3. Note the iOS version, the failing checklist item, and whether the `SW` button appeared. In particular, a visible button with no audible effects suggests the current video player may not route audio through `AVPlayerItem` audio taps.

This checklist is a testing guide, not evidence that the prototype has passed these checks.

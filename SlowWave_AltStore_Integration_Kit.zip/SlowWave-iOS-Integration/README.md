# SlowWave for YTKACE YouTube — experimental iOS integration

This project is a **native tweak proof-of-concept** based on the uploaded files:

- `YTKACE_21.36.6_0.9.2.ipa`
- `SlowWave 2.zip` (SlowWave browser extension v1.2.0, Manifest V3)

It is not the browser extension copied into YouTube. The extension's Chrome APIs and HTML-video Web Audio graph do not exist in a native UIKit app. This project replaces the main controls/audio path with a native Objective-C++ implementation intended for `AVPlayer` / `AVPlayerItem` playback.

## Current status — read before building

**Source prototype only; not compiled or device-tested. No installable IPA is included.** The environment in which this package was prepared does not have Xcode's iOS SDK, Theos, or Apple signing tools, so I could not compile the `.dylib`, run it in YouTube, or honestly certify that it works.

The uploaded IPA was inspected, not overwritten. The Mach-O load-command patch was tested in memory only. The injector will make a separate output IPA when given a compiled arm64 `SlowWave.dylib`.

The biggest runtime unknown is whether this version of YouTube sends its video audio through an `AVPlayerItem` audio track that accepts an `MTAudioProcessingTap`. If its playback implementation bypasses that path, the overlay may show but audio effects will not process video. The private YouTube overlay class name may also differ, preventing the button from appearing. Those points require a real device test.

## Intended controls

- `SW` button on the video-player overlay to open SlowWave settings
- On/off switch; settings saved in `NSUserDefaults`
- Playback speed from 0.50× to 1.50×, with varispeed/pitch changing
- Bass boost (0–20 dB), reverb (0–100%), delay (0–500 ms), mid/treble EQ, master gain, wet mix
- Starter presets: Slow, Ultra, Dreamy, Bass, Clean

The custom native DSP is an approximation of the extension's Web Audio chain, not an exact binary-for-binary port. It uses a small delay/comb-feedback reverb rather than Web Audio's convolution impulse, and does not yet reproduce every browser-only feature (such as the live spectrum meter, per-effect toggles, and custom presets).

## Project files

- `Tweak.mm` — Objective-C++ prototype: UI, AVPlayer hooks, audio-tap attachment and DSP
- `Makefile` — Theos build configuration for arm64 / iOS 17+
- `scripts/inspect_ipa.py` — inspect the uploaded IPA and dry-run the Mach-O patch
- `scripts/inject_ipa.py` — embed a compiled dylib and add a weak load command; does not sign
- `scripts/verify_ipa.py` — verify that the output IPA has the load command and embedded dylib
- `BUILD_STATUS.md` — known limitations and test status

## Build on a Mac

Theos' macOS instructions require **full Xcode**, not only the Command Line Tools. Official setup: <https://theos.dev/docs/installation-macos>.

1. Install and open Xcode, install the matching command-line tools, and accept its license.
2. Install Theos using the official instructions. The upstream installer command is:

   ```sh
   bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"
   ```

3. In Terminal, enter this project directory and build:

   ```sh
   make
   ```

   A successful build should create `dist/SlowWave.dylib`. **A successful compile does not establish that the YouTube playback hook works.** Fix any compiler errors first; this source has not been compiled in the preparation environment.

4. Keep the original IPA untouched and create a separate patched copy:

   ```sh
   python3 scripts/inspect_ipa.py /path/to/YTKACE_21.36.6_0.9.2.ipa
   python3 scripts/inject_ipa.py \
     /path/to/YTKACE_21.36.6_0.9.2.ipa \
     dist/SlowWave.dylib \
     --out dist/YTKACE_21.36.6_SlowWave.ipa
   python3 scripts/verify_ipa.py dist/YTKACE_21.36.6_SlowWave.ipa
   ```

5. Import the separate output IPA into AltStore and let AltStore sign it with your developer account. Modifying the Mach-O invalidates the original code signature; **do not install the patched IPA without re-signing it**. Keep a copy of your original IPA so you can revert if the build crashes or does not show the effect controls.

## Important limitations

- The original app declares minimum iOS 17.0. If your device is below iOS 17, this particular IPA is not the right base.
- This experiment hooks `AVPlayer` and uses `AVMutableAudioMixInputParameters.audioTapProcessor`, a public AVFoundation API. That is a plausible audio-processing route, but YouTube's streaming playback behavior must be tested.
- The UI hook uses private YouTube class names (`YTMainAppVideoPlayerOverlayView`, with `YTPlayerViewController` as a fallback). These names can change between YouTube versions.
- The injector checks the bundle ID, arm64 Mach-O, framework run path, available header padding, output archive integrity, and embedded library bytes. It is not a code-signing tool and does not validate runtime behavior.
- This package does not include or redistribute a rebuilt copy of YouTube. It operates on the IPA you supplied locally.

## Reference documentation

- Theos macOS setup: <https://theos.dev/docs/installation-macos>
- Apple `AVMutableAudioMixInputParameters`: <https://developer.apple.com/documentation/avfoundation/avmutableaudiomixinputparameters>
- Apple `audioTapProcessor` property: <https://developer.apple.com/documentation/avfoundation/avmutableaudiomixinputparameters/audiotapprocessor>
